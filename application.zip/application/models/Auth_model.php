<?php
class Auth_model extends CI_Model{

    public funtion __construct(){
        parent::__construct();  
    }
    
}